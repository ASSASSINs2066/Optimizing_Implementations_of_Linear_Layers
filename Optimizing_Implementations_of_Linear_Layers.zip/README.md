# Optimizing_Implementations_of_Linear_Layers

This contains the source code of the paper entitled "Optimizing Implementations of Linear Layers"
